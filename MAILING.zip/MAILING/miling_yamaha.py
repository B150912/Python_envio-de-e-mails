# -*- coding: utf-8 -*-
"""
Created on Fri Oct 28 16:47:41 2022

@author: bruno.andriolli
"""

import pandas as pd
import pyodbc as sql
from bot_telegram import tel

server = '192.168.200.250'
database = 'OLOS_ESPELHO'
username = 'mis'
password = 'jarezende123@2018'

cnn = sql.connect('DRIVER={ODBC Driver 13 for SQL Server};SERVER='+server+';DATABASE='+database+';UID='+username+';PWD='+ password)
cursor = cnn.cursor()

esql = '''SELECT 
          SUBSTRING(FILENAME,1,CHARINDEX('_OLOS',FILENAME)-1) AS MAILING, 
          LEFT(CONVERT(CHAR,DATEPROCCESS,114),8) HORA_IMP,
          TotalRecordsImported AS LINHAS_IMP,
          TotalPhoneNumbersImported AS TEL_IMP,
          TotalBlackListPhoneNumbers AS TEL_BL
          FROM OLOS_ESPELHO.DBO.ReportImport
          WHERE [FileName] LIKE 'YAMAHA%'
          AND CAST(DateProccess AS DATE) = CAST(GETDATE() AS DATE)
'''

df = pd.read_sql(esql, cnn)

if len(df)> 0:
    for index, row in df.iterrows():
        tel('Mailing: {} \nImportado com sucesso as {}! \nTotal de linhas importadas: {} '.format(row.MAILING, row.HORA_IMP, row.LINHAS_IMP))

